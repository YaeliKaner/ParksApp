export default class Cities {
    id! : number
    name! : string
}
