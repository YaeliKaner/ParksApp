export default class UsersDTO {

        id! : number
        name! : string

}